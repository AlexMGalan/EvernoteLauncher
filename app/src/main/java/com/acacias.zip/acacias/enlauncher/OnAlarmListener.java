package com.android.launcher3;

public interface OnAlarmListener {
    public void onAlarm(Alarm alarm);
}
